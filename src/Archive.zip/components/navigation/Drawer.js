import React from 'react';

function Drawer() {
  return <div>Drawer</div>;
}

export default Drawer;
